# nvim-setup

My custom Neovim setup

## Installation

Download into your config directory

```sh
git clone --depth=1 https://github.com/pml68/nvim-setup ~/.config/nvim
```
