return {
  filetypes = { "html", "typescript", "javascript", "css", "sass", "scss", "less", "svelte" },
}
