return {
  single_file_support = true,
}
